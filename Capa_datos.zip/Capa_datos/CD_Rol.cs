﻿using Capa_entidad;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capa_datos
{
    public class CD_Rol
    {
        public List<Rol> Listar()
        {
            List<Rol> lista = new List<Rol>();

            using (SqlConnection oconexion = new SqlConnection(Conexion.cadena))
            {
                try //capturador de errores
                {
                    StringBuilder query = new StringBuilder();
                    query.AppendLine("Select IDRol,Descripcion from ROL");

                    SqlCommand cmd = new SqlCommand(query.ToString(), oconexion); //Consulta  SQL
                    cmd.CommandType = CommandType.Text; //El comando es tipo texto

                    oconexion.Open();//Se pueda ejecutar

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            lista.Add(new Rol //A la lista se le esta agregando un objeto de la clase permiso.
                            {
                                IDRol = Convert.ToInt32(dr["IDRol"]),
                                Descripcion = dr["Descripcion"].ToString(),
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    lista = new List<Rol>(); //Agregar una lista nueva vacía.
                }
            }
            return lista;
        }
    }
}
