﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient; //Referencias para usar la base de datos sql
using Capa_entidad; //Acceso a Capa Entidad
using System.Collections;

namespace Capa_datos
{
    public class CD_Usuario
    {
        private Rol oRol;

        //Metodos
        public /*List<Usuario>*/ Usuario Login(string _usuario, string _contrasena)
        {
            Usuario usuario = new Usuario();

            try //capturador de errores
            {
                using (SqlConnection oconexion = new SqlConnection(Conexion.cadena))
                {
                    string query = $"select IDUsuario,Documento,NombreCompleto,Correo,Clave,Estado from usuario WHERE Documento='{_usuario}'";
                    SqlCommand cmd = new SqlCommand(query.ToString(), oconexion); //Consulta  SQL
                cmd.CommandType = CommandType.Text; //El comando es tipo texto

                oconexion.Open();//Se pueda ejecutar

                using (SqlDataReader dr = cmd.ExecuteReader())
                {

                    while (dr.Read())
                    {
                            if (dr.GetString(4) != _contrasena) break;
                            usuario.IDUsuario = dr.GetInt32(0);
                            usuario.Documento = dr.GetString(1);
                            usuario.Nombrecompleto = dr.GetString(2);
                            usuario.Correo = dr.GetString(3);
                            usuario.Clave = dr.GetString(4);
                            usuario.Estado = dr.GetBoolean(5);
                           

                     }
                }
            }
            }

            catch (Exception ex)
            {
                return new Usuario(); //Agregar una lista nueva vacía.
            }
            return usuario;
        }

    }
}
