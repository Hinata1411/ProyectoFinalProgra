﻿using Capa_entidad;
using System;
using System.Data.SqlClient;

namespace Capa_datos
{
    internal class CD_ClienteBase
    {

    
    }
}