﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Capa_datos
{
    public class Conexion
    {
        //Se encarga de enviar a las demas clases la cadena de conexion que está en el archivo App.confing
        public static string cadena = ConfigurationManager.ConnectionStrings["cadena_conexion"].ToString();
       

    }
}
