﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_proyecto.Utilidades
{
    internal class Opcioncombo
    {
        public string Texto { get; set; }
        public object Valor { get; set; }
    }
}
