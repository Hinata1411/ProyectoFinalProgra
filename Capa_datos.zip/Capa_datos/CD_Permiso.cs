﻿using Capa_entidad;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Capa_datos
{
    public class CD_Permiso
    {
        public List<Permiso> Listar(int IDusuario)
        {
            List<Permiso> lista = new List<Permiso>();

            using (SqlConnection oconexion = new SqlConnection(Conexion.cadena))
            {
                try //capturador de errores
                {
                    StringBuilder query = new StringBuilder();
                    query.AppendLine("Select p.IDRol,p.NombreMenu from PERMISO p");
                    query.AppendLine("inner join ROL r on r.IDRol = p.IDRol");
                    query.AppendLine("inner join USUARIO u on u.IDRol = r.IDRol");
                    query.AppendLine("where u.IDUsuario = @IDUsuario");


                    SqlCommand cmd = new SqlCommand(query.ToString(), oconexion); //Consulta  SQL
                    cmd.Parameters.AddWithValue("@IDUsuario", IDusuario);
                    cmd.CommandType = CommandType.Text; //El comando es tipo texto

                    oconexion.Open();//Se pueda ejecutar

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            lista.Add(new Permiso //A la lista se le esta agregando un objeto de la clase permiso.
                            {
                                oRol = new Rol() { IDRol = Convert.ToInt32(dr["IDRol"]) },
                                NombreMenu = dr["NombreMenu"].ToString(),
                            });
                        }


                    }
                }
                catch (Exception ex)
                {
                    lista = new List<Permiso>(); //Agregar una lista nueva vacía.
                }
            }
            return lista;
        }
    }
}
