﻿using Capa_entidad;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capa_datos
{
    internal class CD_Cliente
    {
        private Rol oRol;

        //Metodos
        public /*List<Cliente>*/ Cliente Login(string _Cliente, string _contrasena)
        {
            Cliente Cliente = new Cliente();

            try //capturador de errores
            {
                using (SqlConnection oconexion = new SqlConnection(Conexion.cadena))
                {

                    string query = $"select IDCliente,Documento,NombreCompleto,Correo,Telefono,Estado from CLIENTE";
                    SqlCommand cmd = new SqlCommand(query.ToString(), oconexion); //Consulta  SQL
                    cmd.CommandType = CommandType.Text; //El comando es tipo texto

                    oconexion.Open();//Se pueda ejecutar

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            if (dr.GetString(4) != _contrasena) break;
                            Cliente.IDCliente = dr.GetInt32(0);
                            Cliente.Documento = dr.GetString(1);
                            Cliente.Nombrecompleto = dr.GetString(2);
                            Cliente.Correo = dr.GetString(3);
                            Cliente.Telefono = dr.GetString(4);
                            Cliente.Estado = dr.GetBoolean(5);


                        }
                    }
                }
            }

            catch (Exception ex)
            {
                return new Cliente(); //Agregar una lista nueva vacía.
            }
            return Cliente;
        }

    }
}
